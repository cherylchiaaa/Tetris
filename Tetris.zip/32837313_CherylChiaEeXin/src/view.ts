export {updateView}
import { addBlock, createCube } from "./state";
import { Viewport, Block, State, BlockState, TetrominoShapes } from "./types";
import { isNotNullOrUndefined, attr } from "./util";

function updateView(onFinish: () => void) {
    return function (s: State):void {
        // Canvas elements
        const svg = document.querySelector("#svgCanvas") as SVGGraphicsElement &
        HTMLElement;
        const preview = document.querySelector("#svgPreview") as SVGGraphicsElement &
        HTMLElement;
        const gameover = document.querySelector("#gameOver") as SVGGraphicsElement &
        HTMLElement;
        const container = document.querySelector("#main") as HTMLElement;

        svg.setAttribute("height", `${Viewport.CANVAS_HEIGHT}`);
        svg.setAttribute("width", `${Viewport.CANVAS_WIDTH}`);
        preview.setAttribute("height", `${Viewport.PREVIEW_HEIGHT}`);
        preview.setAttribute("width", `${Viewport.PREVIEW_WIDTH}`);

        // Text fields
        const levelText = document.querySelector("#levelText") as HTMLElement;
        const scoreText = document.querySelector("#scoreText") as HTMLElement;
        const highScoreText = document.querySelector("#highScoreText") as HTMLElement;
        const powerUpText = document.querySelector("#powerUpText") as HTMLElement;

        levelText.textContent = `${s.level}`;
        scoreText.textContent = `${s.score}`;
        highScoreText.textContent = `${s.highScore}`;
        powerUpText.textContent = `${s.powerUp}`

        /** Rendering (side effects) */

        /**
         * Displays a SVG element on the canvas. Brings to foreground.
         * @param elem SVG element to display
         */
        const show = (elem: SVGGraphicsElement) => {
            elem.setAttribute("visibility", "visible");
            elem.parentNode!.appendChild(elem);
        };
        
        /**
         * Hides a SVG element on the canvas.
         * @param elem SVG element to hide
         */
        const hide = (elem: SVGGraphicsElement) =>
            elem.setAttribute("visibility", "hidden");
        
        /**
         * Creates an SVG element with the given properties.
         *
         * See https://developer.mozilla.org/en-US/docs/Web/SVG/Element for valid
         * element names and properties.
         *
         * @param namespace Namespace of the SVG element
         * @param name SVGElement name
         * @param props Properties to set on the SVG element
         * @returns SVG element
         */
        const createSvgElement = (
            namespace: string | null,
            name: string,
            props: Record<string, string> = {}
        ) => {
            const elem = document.createElementNS(namespace, name) as SVGElement;
            Object.entries(props).forEach(([k, v]) => elem.setAttribute(k, v));
            return elem;
        };

        const updateBlock = (id: string, height: string, width: string, x: string, y: string, style: string) => (element: SVGGraphicsElement & HTMLElement) => 
        { 
            // create a new SVG rect element with specified attributes
            const ele = createSvgElement(element.namespaceURI, "rect", {id: id, height: height, width: width, x: x, y: y, style: style}); 
            element.appendChild(ele); 
            return ele;
        };

        // get existing block element / create a new one then update its attributes
        const renderCurrentBlock = (block: BlockState) => 
        { 
            const v = document.getElementById(block.id) || updateBlock(block.id, block.height, block.width, block.x, block.y, block.style)(svg);
            attr(v, {x: block.x, y: block.y});
        }

        // get existing block element / create a new one then update its attributes
        const renderPreviousBlock = (block: BlockState) => 
        { 
            const v = document.getElementById(block.id) || updateBlock(block.id, block.height, block.width, block.x, block.y, block.style)(svg);
            attr(v,{x:block.x,y:block.y});
        }

        // get existing block element / create a new one then update its attributes
        const renderNextBlock = (block: BlockState) => 
        { 
            const v = document.getElementById(block.id) || updateBlock(block.id, block.height, block.width, block.x, block.y, block.style)(preview);
            attr(v,{x:block.x,y:block.y});
        }

        /**
         * Renders the current state to the canvas.
         *
         * In MVC terms, this updates the View using the Model.
         *
         * @param s Current state
         */
        const render = (s: State) => {
            // Add blocks to the main grid canvas
            if (s.level >= 5) {     // next blocks are not added when game level is >= 5
                s.blocks.currentBlocks.forEach(renderCurrentBlock);
                s.blocks.previousBlocks.forEach(renderPreviousBlock);
            }
            else {      // current, previous and next blocks are added during game level 1, 2, 3, 4
                s.blocks.currentBlocks.forEach(renderCurrentBlock);
                s.blocks.previousBlocks.forEach(renderPreviousBlock);
                s.blocks.nextBlocks.forEach(renderNextBlock);
            }

            // remove next blocks that needs to be removed
            s.blocks.removeNextBlocks.map(o => document.getElementById(o.id))
            .filter(isNotNullOrUndefined)
            .forEach(v => {
                try {
                    preview.removeChild(v)
                } catch (e) {
                }
            })

            // remove current blocks that needs to be removed
            s.blocks.removeCurrentBlocks.map(o => document.getElementById(o.id))
            .filter(isNotNullOrUndefined)
            .forEach(v => {
                try {
                    svg.removeChild(v)
                } catch (e) {
                }
            })

            // remove previous blocks that needs to be removed
            s.blocks.removePreviousBlocks.map(o => document.getElementById(o.id))
            .filter(isNotNullOrUndefined)
            .forEach(v => {
                try {
                    svg.removeChild(v)
                } catch (e) {
                }
            })
        };
        render(s);

        if (s.gameEnd) {
            show(gameover);
        } else {
            hide(gameover);
        }
    }
}