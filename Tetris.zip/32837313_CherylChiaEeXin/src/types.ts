export type { Key, Event, State, BlockState, Action }
export { Viewport, Constants, Block, TetrominoShapes, rowNumber }

/** Constants */

const Viewport = {
    CANVAS_WIDTH: 200,      // width of game canvas
    CANVAS_HEIGHT: 400,     // height of game canvas
    PREVIEW_WIDTH: 160,     // width of preview canvas
    PREVIEW_HEIGHT: 80,     // height of preview canvas
} as const;
  
const Constants = {
    TICK_RATE_MS: 500,      // time interval for game ticks
    GRID_WIDTH: 10,     // width of grid
    GRID_HEIGHT: 20,        // height of grid
} as const;
  
const Block = {
    WIDTH: Viewport.CANVAS_WIDTH / Constants.GRID_WIDTH,        // width of a game block
    HEIGHT: Viewport.CANVAS_HEIGHT / Constants.GRID_HEIGHT,     // height of a game block
};
  
const TetrominoShapes: string[] = ["I", "O", "T", "S", "Z", "J", "L"];

// array of row numbers
const rowNumber = Array.from({ length: 20 }, (_, index) => index).map((num) => num+1);

/** User input */
  
type Key = "KeyS" | "KeyA" | "KeyD" | "KeyW" | "KeyN" | "KeyP";
  
type Event = "keydown" | "keyup" | "keypress";
  
/** State processing */

type State = Readonly<{
    gameEnd: boolean;
    blocks: Readonly<AllBlock>;
    numOfBlocks: number;
    level: number;
    score: number;
    highScore: number;
    powerUp: number;
}>;

type AllBlock = Readonly<{
    currentBlocks: ReadonlyArray<BlockState>;
    previousBlocks: ReadonlyArray<BlockState>;
    nextBlocks: ReadonlyArray<BlockState>;
    removeCurrentBlocks: ReadonlyArray<BlockState>;
    removePreviousBlocks: ReadonlyArray<BlockState>;
    removeNextBlocks: ReadonlyArray<BlockState>;
}>

type BlockState = Readonly<{
    id: string;
    height: string;
    width: string;
    x: string;
    y: string;
    style: string;
    shapeType: string;
}>

interface Action {
    apply(s: State): State;
} 
  