export { initialState,tick, addBlock, createCube, Tick, reduceState, Move, Rotate, Restart, PowerUp }
import { State, BlockState, Block, Action, TetrominoShapes, Viewport, rowNumber } from "./types";
import { updateView } from "./view";
import { RNG } from "./util";

// define inital state of game
const initialState: State = {
    gameEnd: false,
    blocks: {
      currentBlocks: [],
      previousBlocks: [],
      nextBlocks: [],
      removeCurrentBlocks: [],
      removePreviousBlocks: [],
      removeNextBlocks: [],
    },
    numOfBlocks: 0,
    level: 1,
    score: 0,
    highScore: 0,
    powerUp: 5,
} as const;

/**
 * state transducer
 * @param s input State
 * @param action type of action to apply to the State
 * @returns a new State 
 * */
const reduceState = (s: State, action: Action) => action.apply(s);

/**
 * Updates the state by proceeding with one time step.
 *
 * @param s Current state
 * @returns Updated state
 */
const tick = (s: State) => s;

// function to create a cube with certain properties
function createCube(n: string, height: string, width: string, x: string, y: string, style: string, shapeType: string): BlockState {
    return {
        id: n,
        height: height,
        width: width,
        x: x,
        y: y,
        style: style,
        shapeType: shapeType
    }
}

// function to create Tetromino according to shape type
const createTetromino = (shapeType: string) => (s: State) => {
    if (shapeType == "I") {
        const shape1 = createCube(String(s.numOfBlocks), "20", "20", "0", "0", "fill: cyan", "I");
        const shape2 = createCube(String(s.numOfBlocks + 1), "20", "20", "20", "0", "fill: cyan", "I");
        const shape3 = createCube(String(s.numOfBlocks + 2), "20", "20", "40", "0", "fill: cyan", "I");
        const shape4 = createCube(String(s.numOfBlocks + 3), "20", "20", "60", "0", "fill: cyan", "I");
        
        const ShapeArrangement = [shape1, shape2, shape3, shape4];
        return ShapeArrangement.reduce((currentState, cube) => addBlock(currentState, cube, "nextBlocks"), s);
    };
    if (shapeType === "O") {
        const shape1 = createCube(String(s.numOfBlocks), "20", "20", "0", "0", "fill: yellow", "O");
        const shape2 = createCube(String(s.numOfBlocks + 1), "20", "20", "20", "0", "fill: yellow", "O");
        const shape3 = createCube(String(s.numOfBlocks + 2), "20", "20", "0", "20", "fill: yellow", "O");
        const shape4 = createCube(String(s.numOfBlocks + 3), "20", "20", "20", "20", "fill: yellow", "O");
        
        const ShapeArrangement = [shape1, shape2, shape3, shape4];

        return ShapeArrangement.reduce((currentState, cube) => addBlock(currentState, cube, "nextBlocks"), s);
    };
    if (shapeType === "T") {
        const shape1 = createCube(String(s.numOfBlocks), "20", "20", "0", "0", "fill: purple", "T");
        const shape2 = createCube(String(s.numOfBlocks + 1), "20", "20", "20", "0", "fill: purple", "T");
        const shape3 = createCube(String(s.numOfBlocks + 2), "20", "20", "40", "0", "fill: purple", "T");
        const shape4 = createCube(String(s.numOfBlocks + 3), "20", "20", "20", "20", "fill: purple", "T");
        
        const ShapeArrangement = [shape1, shape2, shape3, shape4];
        return ShapeArrangement.reduce((currentState, cube) => addBlock(currentState, cube, "nextBlocks"), s);
    };
    if (shapeType === "S") {
        const shape1 = createCube(String(s.numOfBlocks), "20", "20", "40", "0", "fill: green", "S");
        const shape2 = createCube(String(s.numOfBlocks + 1), "20", "20", "20", "0", "fill: green", "S");
        const shape3 = createCube(String(s.numOfBlocks + 2), "20", "20", "0", "20", "fill: green", "S");
        const shape4 = createCube(String(s.numOfBlocks + 3), "20", "20", "20", "20", "fill: green", "S");
        
        const ShapeArrangement = [shape1, shape2, shape3, shape4];

        return ShapeArrangement.reduce((currentState, cube) => addBlock(currentState, cube, "nextBlocks"), s);
    };
    if (shapeType === "Z") {
        const shape1 = createCube(String(s.numOfBlocks), "20", "20", "0", "0", "fill: red", "Z");
        const shape2 = createCube(String(s.numOfBlocks + 1), "20", "20", "20", "0", "fill: red", "Z");
        const shape3 = createCube(String(s.numOfBlocks + 2), "20", "20", "20", "20", "fill: red", "Z");
        const shape4 = createCube(String(s.numOfBlocks + 3), "20", "20", "40", "20", "fill: red", "Z");
        
        const ShapeArrangement = [shape1, shape2, shape3, shape4];

        return ShapeArrangement.reduce((currentState, cube) => addBlock(currentState, cube, "nextBlocks"), s);
    };
    if (shapeType === "J") {
        const shape1 = createCube(String(s.numOfBlocks), "20", "20", "0", "0", "fill: blue", "J");
        const shape2 = createCube(String(s.numOfBlocks + 1), "20", "20", "20", "0", "fill: blue", "J");
        const shape3 = createCube(String(s.numOfBlocks + 2), "20", "20", "40", "0", "fill: blue", "J");
        const shape4 = createCube(String(s.numOfBlocks + 3), "20", "20", "40", "20", "fill: blue", "J");
        
        const ShapeArrangement = [shape1, shape2, shape3, shape4];

        return ShapeArrangement.reduce((currentState, cube) => addBlock(currentState, cube, "nextBlocks"), s);
    };
    if (shapeType === "L") {
        const shape1 = createCube(String(s.numOfBlocks), "20", "20", "40", "0", "fill: orange", "L");
        const shape2 = createCube(String(s.numOfBlocks + 1), "20", "20", "20", "0", "fill: orange", "L");
        const shape3 = createCube(String(s.numOfBlocks + 2), "20", "20", "0", "0", "fill: orange", "L");
        const shape4 = createCube(String(s.numOfBlocks + 3), "20", "20", "0", "20", "fill: orange", "L");
        
        const ShapeArrangement = [shape1, shape2, shape3, shape4];

        return ShapeArrangement.reduce((currentState, cube) => addBlock(currentState, cube, "nextBlocks"), s);
    };

};

// function to add a block to a specific block key into the state
const addBlock = (s: State, block: BlockState, blockKey: keyof State["blocks"]): State => {
    const updateAllBlocks = [...s.blocks[blockKey].concat(block)];
    const updateBlocks = {
        ...s.blocks,
        [blockKey]: updateAllBlocks,
      };
    const updatedState = {
        ...s,
        blocks: updateBlocks,
        numOfBlocks: s.numOfBlocks + 1,
    };
    return updatedState;
}

// function to move next blocks to current blocks
const moveFromNextToCurrent = (s: State): State => {
    const blocksToMove = s.blocks.nextBlocks.slice(0, 4);
    const blocksToAdd = blocksToMove.reduce((stateOfBlock, block) => addBlock(stateOfBlock, block, "currentBlocks"), s);

    const updatedState = {
        ...s,
        blocks: {
            currentBlocks: blocksToAdd.blocks.currentBlocks,
            previousBlocks: s.blocks.previousBlocks,
            nextBlocks: [],
            removeCurrentBlocks: s.blocks.removeCurrentBlocks,
            removePreviousBlocks: s.blocks.removePreviousBlocks,
            removeNextBlocks: blocksToAdd.blocks.currentBlocks,
        },
        numOfBlocks: s.numOfBlocks,
    };

    return updatedState;

}

// function to move current blocks to previous blocks
const moveFromCurrentToPrevious = (s: State): State => {
    const blocksToMove = s.blocks.currentBlocks.slice(0, 4);
    const blocksToAdd = blocksToMove.reduce((stateOfBlock, block) => addBlock(stateOfBlock, block, "previousBlocks"), s);
    const newNextBlocks = s.blocks.currentBlocks.filter((block) => !blocksToMove.includes(block));

    const updatedState = {
        ...s,
        blocks: {
            currentBlocks: newNextBlocks,
            previousBlocks: blocksToAdd.blocks.previousBlocks,
            nextBlocks: s.blocks.nextBlocks,
            removeCurrentBlocks: s.blocks.removeCurrentBlocks,
            removePreviousBlocks: s.blocks.removePreviousBlocks,
            removeNextBlocks: s.blocks.removeNextBlocks,
        },
        numOfBlocks: s.numOfBlocks,
    };
    return updatedState;
}

// action class for advancing game by one tick
class Tick implements Action {
    constructor(public readonly num: number) {}    
    apply (s:State): State{

            // check for game end
            if (s.blocks.previousBlocks.map(block => block.y == "0").includes(true)) {
                return {
                    ...s,
                    gameEnd: true,
                }
            }

            // check for filled rows to clear
            const filledRows = rowNumber.map((num) => 
                // find for blocks in the current row
                s.blocks.previousBlocks.filter((blocks) => parseFloat(blocks.y) == num * 20)
                // check if row is filled
                ).filter((row) => row.length == 10);
            
            // remove blocks that are in filled rows
            if (filledRows.length != 0) {
                // combine the filled rows into one array
                const blocksToClear = filledRows.reduce((total, arr) => total.concat(arr), []);
                // add the blocksToClear into removePreviousBlocks
                const remove = s.blocks.removePreviousBlocks.concat(blocksToClear);
                // remove blocks that are cleared from previousBlocks
                const removeBlocksCleared = s.blocks.previousBlocks.filter((blocks) => !remove.includes(blocks));
                // filter the removeBlocksCleared array to find blocks that are positioned at that row
                const blcoksInClearRow = rowNumber.map((num) => removeBlocksCleared.filter((blocks) => parseFloat(blocks.y) == num * 20));
                const updatedState = blcoksInClearRow.reduceRight((currentState: State, blocks) => {
                    const filteredstate = {
                        ...currentState,
                        blocks:{
                          ...currentState.blocks,
                          previousBlocks: currentState.blocks.previousBlocks.filter((block) => !blocks.includes(block))}
                    }
                    const fallByFourRow = updateCurrentPosition(filteredstate, blocks, 0, 80)
                    const fallByThreeRow = updateCurrentPosition(filteredstate, blocks, 0, 60)
                    const fallByTwoRow = updateCurrentPosition(filteredstate, blocks, 0, 40)
                    const fallByOneRow = updateCurrentPosition(filteredstate, blocks, 0, 20)
                    const combine = (fallByFourRow != blocks) ? fallByFourRow : (fallByThreeRow!=blocks) ? fallByThreeRow : (fallByTwoRow!=blocks) ? fallByTwoRow : fallByOneRow
                    return {
                        ...currentState,
                        blocks:{
                            ...currentState.blocks,
                            previousBlocks: currentState.blocks.previousBlocks.filter((block) => !blocks.includes(block)).concat(combine)
                        }
                    }
                }, 
                {
                    ...s,
                    blocks:{
                        ...s.blocks,
                        removePreviousBlocks: remove,
                        previousBlocks: removeBlocksCleared,
                    }
                });
                return {
                    ...s,
                    blocks:{
                        ...s.blocks,
                        removePreviousBlocks: remove,
                        previousBlocks: updatedState.blocks.previousBlocks,
                    },
                    level: 1 + Math.floor((s.score + filledRows.length) / 10),
                    score: s.score + filledRows.length,
                    highScore: (s.highScore < (s.score + filledRows.length)) ? (s.score + filledRows.length) : (s.highScore),
                }
            };

            // check if current has stop moving
            const position = updateCurrentPosition(s, s.blocks.currentBlocks, 0, 20)
            const x = (s.blocks.currentBlocks.map(block => position.map(updateblock => block == updateblock)))
            const y = x.map(arr => arr.includes(true))
            if (!y.includes(false) && (s.blocks.currentBlocks.length != 0)) {
                return moveFromCurrentToPrevious(s)
            }

            if (s.blocks.nextBlocks.length == 0) {
                const hash_value = RNG.hash(this.num); 
                const scale_value = RNG.scale(hash_value);
                const shapeIndex = Math.floor(scale_value * TetrominoShapes.length);
                const selectedShape = TetrominoShapes[shapeIndex];
    
                const updatedState = createTetromino(selectedShape)(s);
                if (updatedState) {
                    return {
                        ...s,
                        blocks: {
                            ...s.blocks,
                            nextBlocks: updatedState.blocks.nextBlocks
                        },
                        numOfBlocks: updatedState.numOfBlocks
                    };
                }
                
                return s;
            }
            else if (s.blocks.currentBlocks.length == 0) {
                return moveFromNextToCurrent(s);
            }
            else {
                return s;
            }
    }
}

// action class for moving blocks
class Move implements Action {
    constructor(public readonly x_value: number, public readonly y_value: number) {}

    apply(s: State): State {
        return {
            ...s,
            blocks: {
                ...s.blocks,
                currentBlocks: updateCurrentPosition(s, s.blocks.currentBlocks, this.x_value, this.y_value),
            }
        };
    }
}

// action class for rotating blocks
class Rotate implements Action {
    constructor() {}

    apply = (s: State): State => {
        if (s.blocks.currentBlocks.length == 0){
            return s;
        }
        const currentType = s.blocks.currentBlocks[0].shapeType;
        const pivotOfCurrent = findPivotBlock(s.blocks.currentBlocks);

        if (currentType === "I") { 
            const rotatedBlocks = rotateI(s, pivotOfCurrent);
            return rotatedBlocks;
        } 
        else if (currentType === "O") {
            const rotatedBlocks = s;
            return rotatedBlocks;
        } 
        else if (currentType === "T") {
            const rotatedBlocks = rotateTJL(s, pivotOfCurrent);
            return rotatedBlocks;
        } 
        else if (currentType === "S") {
            const rotatedBlocks = rotateS(s, pivotOfCurrent);
            return rotatedBlocks;
        } 
        else if (currentType === "Z") { 
            const rotatedBlocks = rotateZ(s, pivotOfCurrent);
            return rotatedBlocks;
        } 
        else if (currentType === "J") {
            const rotatedBlocks = rotateTJL(s, pivotOfCurrent);
            return rotatedBlocks;
        } 
        else {  // "L"
            const rotatedBlocks = rotateTJL(s, pivotOfCurrent);
            return rotatedBlocks;
        }
    }
}

// function to find pivot block of Tetromino 
const findPivotBlock = (blocks: ReadonlyArray<BlockState>): BlockState => {
    const pivotOfCurrent = blocks[1];
    return pivotOfCurrent;
}

// function for rotating "I" tetromino
const rotateI = (s: State, pivotOfCurrent: BlockState): State => {
    const withoutPivot = s.blocks.currentBlocks.filter((block) => block!= pivotOfCurrent)

    const blockOne = withoutPivot.filter((block) => ( (block.x == String(parseFloat(pivotOfCurrent.x) - 20)) && (block.y == pivotOfCurrent.y) ) || ( (block.x == pivotOfCurrent.x) && (String(parseFloat(block.y) - 20) == pivotOfCurrent.y) ))
        .map((block) => (block.y == pivotOfCurrent.y) && (block.x == String(parseFloat(pivotOfCurrent.x) - 20)) ? {...block, y: String(parseFloat(pivotOfCurrent.y) + 20), x: pivotOfCurrent.x} : {...block, x: String(parseFloat(pivotOfCurrent.x) - 20), y: pivotOfCurrent.y})
    
    const blockTwo = withoutPivot.filter((block) => ((block.y == pivotOfCurrent.y) && (block.x == String(parseFloat(pivotOfCurrent.x) + 20)) || (block.x == pivotOfCurrent.x) && (String(parseFloat(block.y) + 20) == pivotOfCurrent.y) ))
        .map((block) => (block.y == pivotOfCurrent.y) && (block.x == String(parseFloat(pivotOfCurrent.x) + 20)) ? {...block, y: String(parseFloat(pivotOfCurrent.y) - 20), x: pivotOfCurrent.x} :{...block, x: String(parseFloat(pivotOfCurrent.x) + 20), y: pivotOfCurrent.y})
    
    const blockThree = withoutPivot.filter((block) => ((block.y == pivotOfCurrent.y) && (block.x == String(parseFloat(pivotOfCurrent.x) + 40)) || (block.x == pivotOfCurrent.x) && (String(parseFloat(block.y) + 40) == pivotOfCurrent.y) ))
        .map((block) => (block.y == pivotOfCurrent.y) && (block.x == String(parseFloat(pivotOfCurrent.x) + 40)) ? {...block, y: String(parseFloat(pivotOfCurrent.y) - 40), x: pivotOfCurrent.x} : {...block, x: String(parseFloat(pivotOfCurrent.x) + 40), y: pivotOfCurrent.y})
    
    return (needToWallKick(s, ([blockOne[0], pivotOfCurrent, blockTwo[0], blockThree[0]]), s.blocks.currentBlocks))
}

// function for rotating "T", "J", "L" tetromino
const rotateTJL = (s: State, pivotOfCurrent: BlockState): State => {
    const withoutPivot = s.blocks.currentBlocks.filter((block) => block!= pivotOfCurrent)

    const rotation = withoutPivot.map((block) => 
        {
        if (leftOfPivot(pivotOfCurrent, block)) return ({...block, x: pivotOfCurrent.x, y: String(parseFloat(pivotOfCurrent.y) - 20)});
        else if (rightOfPivot(pivotOfCurrent, block)) return ({...block, x: pivotOfCurrent.x, y: String(parseFloat(pivotOfCurrent.y) + 20)});
        else if (topOfPivot(pivotOfCurrent, block)) return ({...block, y: pivotOfCurrent.y, x: String(parseFloat(pivotOfCurrent.x) + 20)});
        else if (bottomOfPivot(pivotOfCurrent, block)) return ({...block,y:pivotOfCurrent.y, x:String(parseFloat(pivotOfCurrent.x) - 20)});
        else if (bottomLeftOfPivot(pivotOfCurrent, block)) return ({...block, y: String(parseFloat(block.y) - 40)});
        else if (topLeftOfPivot(pivotOfCurrent, block)) return ({...block, x: String(parseFloat(block.x) + 40)});
        else if (topRightOfPivot(pivotOfCurrent, block)) return ({...block, y: String(parseFloat(block.y) + 40)});
        else return ({...block, x: String(parseFloat(block.x) - 40)});
        })
    const rotatedBlocks = rotation.concat(pivotOfCurrent)
    const sortRotatedBlocks = rotatedBlocks.slice().sort((a, b) => parseFloat(a.id) - parseFloat(b.id) )
    return (needToWallKick(s, sortRotatedBlocks, s.blocks.currentBlocks))
}

// function for rotating "S" tetromino
const rotateS = (s: State, pivotOfCurrent: BlockState): State => {
    const beforePivot = s.blocks.currentBlocks.filter((block) => block.id == String(parseFloat(pivotOfCurrent.id) - 1))
    const afterPivot1 = s.blocks.currentBlocks.filter((block) => block.id == String(parseFloat(pivotOfCurrent.id) + 1))
    const afterPivot2 = s.blocks.currentBlocks.filter((block) => block.id == String(parseFloat(pivotOfCurrent.id) + 2))
    const blockOne = beforePivot.map((block) => rightOfPivot(pivotOfCurrent, block) ? {...block, x: pivotOfCurrent.x, y: String(parseFloat(pivotOfCurrent.y) + 20)} : {...block, x: String(parseFloat(pivotOfCurrent.x) + 20), y: pivotOfCurrent.y} )
    const blockTwo = afterPivot1.map((block) => bottomLeftOfPivot(pivotOfCurrent, block) ? {...block, y: String(parseFloat(block.y) - 40)} : {...block, y: String(parseFloat(block.y) + 40)} )
    const blockThree = afterPivot2.map((block) => leftOfPivot(pivotOfCurrent, block) ? {...block, x: pivotOfCurrent.x, y: String(parseFloat(pivotOfCurrent.y) + 20)} : {...block, y: pivotOfCurrent.y, x: String(parseFloat(pivotOfCurrent.x) - 20)} )
    return (needToWallKick(s, ([blockOne[0], pivotOfCurrent, blockTwo[0], blockThree[0]]), s.blocks.currentBlocks))
}

// function for rotating "Z" tetromino
const rotateZ = (s: State, pivotOfCurrent: BlockState): State => {
    const beforePivot = s.blocks.currentBlocks.filter((block) => block.id == String(parseFloat(pivotOfCurrent.id) - 1))
    const afterPivot1 = s.blocks.currentBlocks.filter((block) => block.id == String(parseFloat(pivotOfCurrent.id) + 1))
    const afterPivot2 = s.blocks.currentBlocks.filter((block) => block.id == String(parseFloat(pivotOfCurrent.id) + 2))
    const blockOne = beforePivot.map((block) => leftOfPivot(pivotOfCurrent, block) ? {...block, x :pivotOfCurrent.x, y: String(parseFloat(pivotOfCurrent.y) - 20)} : {...block, y: pivotOfCurrent.y, x: String(parseFloat(pivotOfCurrent.x) - 20)} )
    const blockTwo = afterPivot1.map((block) => leftOfPivot(pivotOfCurrent, block) ? {...block, x: pivotOfCurrent.x, y: String(parseFloat(pivotOfCurrent.y) + 20)} : {...block, y: pivotOfCurrent.y, x: String(parseFloat(pivotOfCurrent.x) - 20)} )
    const blockThree = afterPivot2.map((block) => bottomLeftOfPivot(pivotOfCurrent, block) ? {...block, x: String(parseFloat(block.x) + 40)}: { ...block, x: String(parseFloat(block.x) - 40)} )
    return (needToWallKick(s, ([blockOne[0], pivotOfCurrent, blockTwo[0], blockThree[0]]), s.blocks.currentBlocks))
}

// action class for restarting game
class Restart implements Action{
    constructor () {}
    apply = (s:State): State => {
        const startState = initialState;
        return {
            ...startState,
            blocks: {
                ...startState.blocks,
                removeCurrentBlocks: s.blocks.currentBlocks,
                removePreviousBlocks: s.blocks.previousBlocks,
                removeNextBlocks: s.blocks.nextBlocks
            },
            numOfBlocks: s.numOfBlocks,
            highScore: s.highScore,
        }
    }
}

// action class for using power up
class PowerUp implements Action {
    constructor () {}
    apply = (s:State): State => {
        if (s.powerUp > 0){
            const updatedState = {
                ...s,
                blocks: {
                    ...s.blocks,
                    currentBlocks: [],
                    removeCurrentBlocks: s.blocks.removeCurrentBlocks.concat(s.blocks.currentBlocks),
                },
                powerUp: s.powerUp - 1,
            }
            return updatedState
        }
        return s;
    }
}

// check if block is top of pivot
const topOfPivot = (pivot: BlockState, block: BlockState) => {
    return (block.x == pivot.x) && (block.y == String(parseFloat(pivot.y) - 20))
}

// check if block is bottom of pivot
const bottomOfPivot = (pivot: BlockState, block: BlockState) => {
    return (block.x == pivot.x) && (block.y == String(parseFloat(pivot.y) + 20))
}

// check if block is left of pivot
const leftOfPivot = (pivot: BlockState, block: BlockState) => {
    return (block.y == pivot.y) && (block.x == String(parseFloat(pivot.x) - 20))
}

// check if block is right of pivot
const rightOfPivot = (pivot: BlockState, block: BlockState) => {
    return (block.y == pivot.y) && (block.x == String(parseFloat(pivot.x) + 20))
}

// check if block is top left of pivot
const topLeftOfPivot = (pivot: BlockState, block: BlockState) => {
    return (block.y == String(parseFloat(pivot.y) - 20)) && (block.x == String(parseFloat(pivot.x) - 20))
}

// check if block is top right of pivot
const topRightOfPivot = (pivot: BlockState, block: BlockState) => {
    return (block.y == String(parseFloat(pivot.y) - 20)) && (block.x == String(parseFloat(pivot.x) + 20))
}

// check if block is bottom left of pivot
const bottomLeftOfPivot = (pivot:BlockState,block:BlockState) => {
    return (block.y == String(parseFloat(pivot.y) + 20)) && (block.x == String(parseFloat(pivot.x) - 20))
}

// check if block is bottom right of pivot
const bottomRightOfPivot = (pivot:BlockState,block:BlockState) => {
    return (block.y == String(parseFloat(pivot.y) + 20)) && (block.x == String(parseFloat(pivot.x) + 20))
}

// check movement does not go out of bounds
const block_movement_within_bound = (b: BlockState | undefined, x_value: number, y_value: number): boolean => {
    if (!b) return false;
    return (
        parseFloat(b.x) + x_value >= 0 &&
        parseFloat(b.x) + x_value <= 180 &&
        parseFloat(b.y) + y_value <= 380
    );
};

// updates the new position of current blocks
const updateCurrentPosition = (s: State, blocks: ReadonlyArray<BlockState>, x_value: number, y_value: number) => {
    const AllBlocksInBound = blocks.map(block => block_movement_within_bound(block, x_value, y_value));
    const collision = collisionHandler(s, blocks, y_value);
    if (!AllBlocksInBound.includes(false) && !collision.includes(true)) {
        const updatedBlocks = blocks.map(block => ({
            ...block,
            x: String(parseFloat(block.x) + x_value),
            y: String(parseFloat(block.y) + y_value),
        }));

        return updatedBlocks;
    };
    return blocks;
};

// function to check for collision 
const collisionHandler = (s: State, updatedBlocks: ReadonlyArray<BlockState>, y_value: number) => {
    const collisions = updatedBlocks.map(block => {
        const newY = parseFloat(block.y) + y_value;
        return (collisionWithUsedBlocks(block, newY, s.blocks.previousBlocks));
    });
    return collisions;
}

// function to check for collision with previous blocks
const collisionWithUsedBlocks = (block: BlockState, newY: number, previousBlocks: ReadonlyArray<BlockState>): boolean => {
    // Check if the block collides with existing blocks in the used (previous) blocks array
    const collisionArray = previousBlocks.map(previousBlocks =>
        previousBlocks.x === block.x && previousBlocks.y === String(newY)
    );
    return collisionArray.includes(true);
};

// function to wall kick
const wallKick = (s: State, updatedBlocks: ReadonlyArray<BlockState>, originalBlock: ReadonlyArray<BlockState>): State => {
    
    // move Tetromino one block right
    const moveOneBlockRight = (s: State, blocks:ReadonlyArray<BlockState>) => {
        return updateCurrentPosition(s, blocks, 20, 0)
    }

    // move Tetromino one block left
    const moveOneBlockLeft = (s: State, blocks:ReadonlyArray<BlockState>) => {
        return updateCurrentPosition(s, blocks, -20, 0)
    }

    if (moveOneBlockRight(s, updatedBlocks) == updatedBlocks) {
        if (moveOneBlockLeft(s, updatedBlocks) == updatedBlocks) {
            return {
                ...s, 
                blocks: {
                    ...s.blocks,
                    currentBlocks: originalBlock,
                }
            }
        }
        return  {
            ...s, 
            blocks: {
                ...s.blocks,
                currentBlocks: moveOneBlockLeft(s, updatedBlocks),
            }
        }
    }
    return  {
        ...s, 
        blocks: {
            ...s.blocks,
            currentBlocks: moveOneBlockRight(s, updatedBlocks),
        }
    }
}

// function to check if wall kick is needed
const needToWallKick = (s: State, blocks: ReadonlyArray<BlockState>, originalPos: ReadonlyArray<BlockState>): State => {
    const forAllBlock = blocks.map((block) => block_movement_within_bound(block, parseFloat(block.x), parseFloat(block.y)))
    if (forAllBlock.includes(false)) {
        return wallKick(s, blocks, originalPos);
    }
    else {
        return {
            ...s, 
            blocks: {
                ...s.blocks,
                currentBlocks: blocks,
            }
        }
    }
}