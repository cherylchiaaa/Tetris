/**
 * Inside this file you will use the classes and functions from rx.js
 * to add visuals to the svg element in index.html, animate them, and make them interactive.
 *
 * Study and complete the tasks in observable exercises first to get ideas.
 *
 * Course Notes showing Asteroids in FRP: https://tgdwyer.github.io/asteroids/
 *
 * You will be marked on your functional programming style
 * as well as the functionality that you implement.
 *
 * Document your code!
 */

import "./style.css";
import { fromEvent, interval, merge , Subscription } from "rxjs";
import { map, filter, scan } from "rxjs/operators";
import { Viewport, Constants, Block, Key, Event, State } from "./types"
import { initialState, reduceState, Tick, Move, Rotate, Restart, PowerUp } from "./state";
import { updateView } from "./view"; 

/**
 * This is the function called on page load. Your main game loop
 * should be called here.
 */
export function main() {
  
  /** User input */

  // observable for keyboard events
  const key$ = fromEvent<KeyboardEvent>(document, "keypress");

  // helper function to create an observable for a specific key code
  const fromKey = (keyCode: Key) =>
    key$.pipe(filter(({ code }) => code === keyCode));

  // observables for specific key code
  const left$ = fromKey("KeyA").pipe(map(_ => new Move(-20,0)));;
  const right$ = fromKey("KeyD").pipe(map(_ => new Move(20,0)));;
  const down$ = fromKey("KeyS").pipe(map(_ => new Move(0,20)));;
  const up$ = fromKey("KeyW").pipe(map(_ => new Rotate()));
  const restart$ = fromKey("KeyN").pipe(map(_ => new Restart()));
  const powerUp$ = fromKey("KeyP").pipe(map(_ => new PowerUp()))

  /** Observables */

  /** Determines the rate of time steps */
  const tick$ = interval(Constants.TICK_RATE_MS);
  const drop = tick$.pipe(map(() => new Move(0,20)));
  const ticks = tick$.pipe(map((x) => new Tick(x)));

  // merge all observables into one observable
  const source$ = merge(ticks, left$, right$, down$, up$, restart$, powerUp$, drop)
    .pipe(scan(reduceState, initialState))

  // subscribe to source$ observable and update view
  const subscription: Subscription = source$.subscribe(updateView(()=>subscription.unsubscribe()));
  }

// The following simply runs your main function on window load.  Make sure to leave it in place.
if (typeof window !== "undefined") {
  window.onload = () => {
    main();
  };
}